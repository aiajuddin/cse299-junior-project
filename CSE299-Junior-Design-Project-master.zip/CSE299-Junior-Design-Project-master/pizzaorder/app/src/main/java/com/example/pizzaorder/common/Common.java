package com.example.pizzaorder.common;

import com.example.pizzaorder.User;

public class Common {

    public static User currentUser;
}
